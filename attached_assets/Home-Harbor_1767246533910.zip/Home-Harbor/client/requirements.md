## Packages
framer-motion | For smooth page transitions and micro-interactions
lucide-react | For beautiful iconography (already in base, but emphasizing usage)
clsx | For conditional class merging
tailwind-merge | For handling tailwind class conflicts

## Notes
Tailwind Config: Extended with brand colors (primary: blue, secondary: light blue/gray) and fonts.
Images: Using Unsplash placeholders for properties.
Auth: Standard email/password flow.
State: TanStack Query for server state.
