import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/hooks/use-auth";
import { useCreateProperty } from "@/hooks/use-properties";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertPropertySchema, type InsertProperty } from "@shared/schema";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useLocation } from "wouter";
import { Loader2 } from "lucide-react";
import { z } from "zod";

// Enhance schema with client-side coercion for number inputs
const formSchema = insertPropertySchema.extend({
  price: z.coerce.number(),
  bedrooms: z.coerce.number(),
  bathrooms: z.coerce.number(),
  area: z.coerce.number(),
  // For simplicity in this demo, amenities are handled as a comma-sep string in input, transformed before submit
});

export default function PostProperty() {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const createProperty = useCreateProperty();

  const form = useForm<any>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      type: "buy",
      title: "",
      description: "",
      price: 0,
      city: "",
      location: "",
      bedrooms: 1,
      bathrooms: 1,
      area: 0,
      images: ["https://images.unsplash.com/photo-1600596542815-6ad4c727dd2d"],
      amenities: ["Parking", "Lift", "Security"], // Default for demo
    },
  });

  if (isLoading) return <div className="h-screen flex items-center justify-center"><Loader2 className="animate-spin" /></div>;
  
  if (!user) {
    setLocation("/login");
    return null;
  }

  const onSubmit = (data: any) => {
    // Inject ownerId (handled by backend session usually, but schema has it)
    // Actually our schema `insertPropertySchema` has `ownerId`.
    // We should let backend handle it from session, OR pass it if schema requires.
    // Based on provided schema `ownerId` is integer references users.id.
    // We'll pass it.
    
    createProperty.mutate({
      ...data,
      ownerId: user.id,
      images: [
        "https://images.unsplash.com/photo-1600596542815-6ad4c727dd2d",
        "https://images.unsplash.com/photo-1512917774080-9991f1c4c750"
      ], // Hardcoded for demo
      amenities: ["Gym", "Pool", "Parking", "Security"], // Hardcoded for demo
    }, {
      onSuccess: () => setLocation("/dashboard")
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Navbar />
      <div className="container mx-auto px-4 py-12 max-w-3xl">
        <div className="bg-white p-8 rounded-2xl shadow-xl border">
          <h1 className="text-3xl font-display font-bold mb-2">Post Your Property</h1>
          <p className="text-muted-foreground mb-8">Fill in the details to list your property for free.</p>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem className="col-span-2">
                      <FormLabel>Property Title</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. 3 BHK Luxury Apartment in Bandra" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>I want to</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select Type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="buy">Sell</SelectItem>
                          <SelectItem value="rent">Rent Out</SelectItem>
                          <SelectItem value="project">List New Project</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="price"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Expected Price (₹)</FormLabel>
                      <FormControl>
                        <Input type="number" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="city"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>City</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Mumbai" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="location"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Locality</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Bandra West" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="bedrooms"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Bedrooms</FormLabel>
                      <FormControl>
                        <Input type="number" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                 <FormField
                  control={form.control}
                  name="bathrooms"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Bathrooms</FormLabel>
                      <FormControl>
                        <Input type="number" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="area"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Carpet Area (sq ft)</FormLabel>
                      <FormControl>
                        <Input type="number" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Describe the key features of your property..." className="h-32" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="pt-4">
                <Button type="submit" size="lg" className="w-full text-lg" disabled={createProperty.isPending}>
                  {createProperty.isPending ? <><Loader2 className="animate-spin mr-2" /> Posting...</> : "Post Property"}
                </Button>
              </div>
            </form>
          </Form>
        </div>
      </div>
      <Footer />
    </div>
  );
}
