import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { PropertyCard } from "@/components/PropertyCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useProperties } from "@/hooks/use-properties";
import { Search, ArrowRight, TrendingUp, Home as HomeIcon, Building2 } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";

export default function Home() {
  const { data: featuredProperties, isLoading } = useProperties();
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setLocation(`/buy?city=${searchQuery}`);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center justify-center bg-slate-900 overflow-hidden">
        {/* Abstract Background */}
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900 to-slate-800 z-0" />
        <div className="absolute inset-0 opacity-20 bg-[url('https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80')] bg-cover bg-center z-0" />
        
        <div className="container relative z-10 px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-display font-bold text-white mb-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
            Find Your Dream Home <br />
            <span className="text-primary bg-clip-text">Without The Hassle</span>
          </h1>
          <p className="text-lg md:text-xl text-slate-300 mb-8 max-w-2xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-1000 delay-200">
            Explore thousands of verified properties in your city. Buy, Rent, or Invest with confidence.
          </p>

          {/* Search Bar */}
          <form onSubmit={handleSearch} className="max-w-3xl mx-auto bg-white p-2 rounded-2xl shadow-2xl flex flex-col md:flex-row gap-2 animate-in zoom-in duration-500 delay-300">
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
              <Input 
                className="pl-12 border-0 shadow-none text-lg h-12 focus-visible:ring-0" 
                placeholder="Search by city, locality, or project..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            <Button size="lg" className="rounded-xl h-12 px-8 text-lg font-medium shadow-lg shadow-primary/20">
              Search
            </Button>
          </form>

          {/* Quick Tags */}
          <div className="mt-8 flex flex-wrap justify-center gap-4 animate-in fade-in delay-500">
            {['Mumbai', 'Bangalore', 'Delhi NCR', 'Pune'].map(city => (
              <button 
                key={city}
                onClick={() => setLocation(`/buy?city=${city}`)}
                className="px-4 py-2 rounded-full bg-white/10 text-white hover:bg-white/20 backdrop-blur-sm text-sm transition-all"
              >
                {city}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 bg-secondary/50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-background p-8 rounded-2xl shadow-sm border hover:border-primary/50 transition-colors">
              <div className="w-12 h-12 bg-blue-100 text-primary rounded-xl flex items-center justify-center mb-6">
                <HomeIcon className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold mb-3">Buy a Home</h3>
              <p className="text-muted-foreground mb-6">Find your place with an immersive photo experience and the most listings, including things you won't find anywhere else.</p>
              <Button variant="outline" onClick={() => setLocation('/buy')}>Browse Homes</Button>
            </div>
            <div className="bg-background p-8 rounded-2xl shadow-sm border hover:border-primary/50 transition-colors">
              <div className="w-12 h-12 bg-green-100 text-green-600 rounded-xl flex items-center justify-center mb-6">
                <TrendingUp className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold mb-3">Rent a Home</h3>
              <p className="text-muted-foreground mb-6">We’re creating a seamless online experience – from shopping on the largest rental network, to applying, to paying rent.</p>
              <Button variant="outline" onClick={() => setLocation('/rent')}>Find Rentals</Button>
            </div>
            <div className="bg-background p-8 rounded-2xl shadow-sm border hover:border-primary/50 transition-colors">
              <div className="w-12 h-12 bg-purple-100 text-purple-600 rounded-xl flex items-center justify-center mb-6">
                <Building2 className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold mb-3">New Projects</h3>
              <p className="text-muted-foreground mb-6">Discover newly launched projects from top developers. Get early bird offers and exclusive inventory access.</p>
              <Button variant="outline" onClick={() => setLocation('/new-launch')}>Explore Projects</Button>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Properties */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-end mb-10">
            <div>
              <h2 className="text-3xl font-display font-bold mb-2">Featured Properties</h2>
              <p className="text-muted-foreground">Handpicked properties just for you</p>
            </div>
            <Button variant="ghost" className="gap-2" onClick={() => setLocation('/buy')}>
              View All <ArrowRight className="w-4 h-4" />
            </Button>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[1, 2, 3].map(i => (
                <div key={i} className="h-[400px] bg-secondary animate-pulse rounded-xl" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredProperties?.slice(0, 3).map((property) => (
                <PropertyCard key={property.id} property={property} />
              ))}
            </div>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
}
