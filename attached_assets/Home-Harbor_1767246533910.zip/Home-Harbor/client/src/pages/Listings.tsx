import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { PropertyCard } from "@/components/PropertyCard";
import { useProperties } from "@/hooks/use-properties";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Search } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";

interface ListingsProps {
  type: 'buy' | 'rent' | 'new-launch';
}

export default function Listings({ type }: ListingsProps) {
  const [city, setCity] = useState("");
  const [bedrooms, setBedrooms] = useState<string>("");
  const [priceRange, setPriceRange] = useState<string>("");
  
  // Parse price range for API
  const [minPrice, maxPrice] = priceRange.split('-').map(Number);
  
  const { data: properties, isLoading } = useProperties({ 
    type: type === 'new-launch' ? 'project' : type,
    city: city || undefined,
    bedrooms: bedrooms ? parseInt(bedrooms) : undefined,
    minPrice: minPrice || undefined,
    maxPrice: maxPrice || undefined
  });

  const pageTitle = type === 'buy' ? 'Properties for Sale' 
    : type === 'rent' ? 'Properties for Rent' 
    : 'New Launch Projects';

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <Navbar />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold text-foreground">{pageTitle}</h1>
            <p className="text-muted-foreground mt-1">Found {properties?.length || 0} properties</p>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white p-4 rounded-xl shadow-sm border mb-8 grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input 
              placeholder="Search City..." 
              className="pl-9"
              value={city}
              onChange={(e) => setCity(e.target.value)}
            />
          </div>
          
          <Select value={bedrooms} onValueChange={setBedrooms}>
            <SelectTrigger>
              <SelectValue placeholder="Bedrooms" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="0">Any</SelectItem>
              <SelectItem value="1">1 BHK</SelectItem>
              <SelectItem value="2">2 BHK</SelectItem>
              <SelectItem value="3">3 BHK</SelectItem>
              <SelectItem value="4">4+ BHK</SelectItem>
            </SelectContent>
          </Select>

          <Select value={priceRange} onValueChange={setPriceRange}>
            <SelectTrigger>
              <SelectValue placeholder="Price Range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">Any Price</SelectItem>
              <SelectItem value="0-5000000">Under 50L</SelectItem>
              <SelectItem value="5000000-10000000">50L - 1 Cr</SelectItem>
              <SelectItem value="10000000-20000000">1 Cr - 2 Cr</SelectItem>
              <SelectItem value="20000000-100000000">Above 2 Cr</SelectItem>
            </SelectContent>
          </Select>

          <Button variant="secondary" onClick={() => {
            setCity("");
            setBedrooms("");
            setPriceRange("");
          }}>
            Reset Filters
          </Button>
        </div>

        {/* Grid */}
        {isLoading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-10 h-10 animate-spin text-primary" />
          </div>
        ) : properties?.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-xl border border-dashed">
            <h3 className="text-xl font-bold text-muted-foreground">No properties found</h3>
            <p className="text-muted-foreground">Try adjusting your filters</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {properties?.map((property) => (
              <PropertyCard key={property.id} property={property} />
            ))}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
