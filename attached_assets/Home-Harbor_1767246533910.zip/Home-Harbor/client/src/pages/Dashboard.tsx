import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { useAuth } from "@/hooks/use-auth";
import { useProperties, useDeleteProperty } from "@/hooks/use-properties";
import { Button } from "@/components/ui/button";
import { Loader2, Trash2, Edit2, Eye } from "lucide-react";
import { Link, useLocation } from "wouter";
import { PropertyCard } from "@/components/PropertyCard";

export default function Dashboard() {
  const { user, isLoading: isAuthLoading } = useAuth();
  const [, setLocation] = useLocation();
  // In a real app, we'd have a specific "my-properties" endpoint. 
  // Here we'll filter client side for simplicity or assume backend returns only user's if scoped
  // For this demo, let's fetch all and filter by ownerId on client to be safe with existing hooks
  const { data: properties, isLoading: isPropsLoading } = useProperties(); 
  const deleteProperty = useDeleteProperty();

  if (isAuthLoading) return <div className="h-screen flex items-center justify-center"><Loader2 className="animate-spin" /></div>;

  if (!user) {
    setLocation("/login");
    return null;
  }

  const myProperties = properties?.filter(p => p.ownerId === user.id) || [];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Navbar />
      <div className="container mx-auto px-4 py-12">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-display font-bold">My Dashboard</h1>
            <p className="text-muted-foreground">Manage your listings and enquiries</p>
          </div>
          <Link href="/post-property">
            <Button>Post New Property</Button>
          </Link>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border overflow-hidden">
          <div className="p-6 border-b bg-slate-50/50">
            <h2 className="text-xl font-bold">Your Listings ({myProperties.length})</h2>
          </div>
          
          {isPropsLoading ? (
            <div className="p-12 text-center"><Loader2 className="animate-spin mx-auto" /></div>
          ) : myProperties.length === 0 ? (
            <div className="p-12 text-center text-muted-foreground">
              You haven't posted any properties yet.
            </div>
          ) : (
            <div className="divide-y">
              {myProperties.map(property => (
                <div key={property.id} className="p-6 flex flex-col md:flex-row gap-6 items-center">
                  <div className="w-full md:w-48 h-32 rounded-lg overflow-hidden flex-shrink-0">
                    <img 
                      src={property.images[0] || "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800&q=80"} 
                      className="w-full h-full object-cover" 
                      alt="Property" 
                    />
                  </div>
                  <div className="flex-1 text-center md:text-left">
                    <h3 className="font-bold text-lg mb-1">{property.title}</h3>
                    <p className="text-muted-foreground text-sm mb-2">{property.location}, {property.city}</p>
                    <div className="font-semibold text-primary">₹ {(property.price / 100000).toFixed(2)} L</div>
                  </div>
                  <div className="flex gap-2">
                    <Link href={`/property/${property.id}`}>
                      <Button variant="outline" size="sm"><Eye className="w-4 h-4 mr-2" /> View</Button>
                    </Link>
                    <Button 
                      variant="destructive" 
                      size="sm"
                      onClick={() => {
                        if (confirm('Are you sure you want to delete this listing?')) {
                          deleteProperty.mutate(property.id);
                        }
                      }}
                      disabled={deleteProperty.isPending}
                    >
                      <Trash2 className="w-4 h-4 mr-2" /> Delete
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      <Footer />
    </div>
  );
}
