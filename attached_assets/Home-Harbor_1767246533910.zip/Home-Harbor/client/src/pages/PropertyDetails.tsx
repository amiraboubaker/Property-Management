import { useRoute } from "wouter";
import { useProperty, useCreateEnquiry } from "@/hooks/use-properties";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { MapPin, BedDouble, Bath, Square, Calendar, User, Phone, Mail, Share2, Heart, CheckCircle2 } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertEnquirySchema, type InsertEnquiry } from "@shared/schema";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { z } from "zod";

// Create a client-side schema that coerces numeric strings if necessary
// but for this form, fields are text, so we're good with insertEnquirySchema directly.
// We just need to handle propertyId and userId implicitly.

export default function PropertyDetails() {
  const [, params] = useRoute("/property/:id");
  const id = Number(params?.id);
  const { data: property, isLoading } = useProperty(id);
  const { user } = useAuth();
  const createEnquiry = useCreateEnquiry();
  const [activeImage, setActiveImage] = useState(0);

  const form = useForm<Omit<InsertEnquiry, "propertyId" | "userId">>({
    resolver: zodResolver(insertEnquirySchema.omit({ propertyId: true, userId: true })),
    defaultValues: {
      name: user?.name || "",
      email: user?.email || "",
      phone: "",
      message: "I am interested in this property. Please contact me.",
    },
  });

  const onSubmit = (data: Omit<InsertEnquiry, "propertyId" | "userId">) => {
    createEnquiry.mutate({
      ...data,
      propertyId: id,
      userId: user?.id,
    });
  };

  if (isLoading) return <div className="min-h-screen flex items-center justify-center"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div></div>;
  if (!property) return <div className="min-h-screen flex items-center justify-center">Property not found</div>;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Navbar />

      <div className="container mx-auto px-4 py-8">
        {/* Header Info */}
        <div className="flex flex-col md:flex-row justify-between items-start mb-6">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <Badge variant="outline" className="text-primary border-primary uppercase tracking-wider">{property.type}</Badge>
              {property.isVerified && <Badge className="bg-green-600 hover:bg-green-700"><CheckCircle2 className="w-3 h-3 mr-1" /> Verified</Badge>}
              <span className="text-muted-foreground text-sm flex items-center"><Calendar className="w-3 h-3 mr-1" /> Posted {new Date(property.createdAt!).toLocaleDateString()}</span>
            </div>
            <h1 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-2">{property.title}</h1>
            <p className="text-muted-foreground flex items-center text-lg"><MapPin className="w-5 h-5 mr-1 text-primary" /> {property.location}, {property.city}</p>
          </div>
          <div className="mt-4 md:mt-0 flex flex-col items-end">
            <div className="text-3xl font-bold text-primary mb-2">₹ {(property.price / 100000).toFixed(2)} Lakhs</div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="gap-2"><Share2 className="w-4 h-4" /> Share</Button>
              <Button variant="outline" size="sm" className="gap-2"><Heart className="w-4 h-4" /> Save</Button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            
            {/* Gallery */}
            <div className="space-y-4">
              <div className="aspect-video rounded-2xl overflow-hidden bg-black shadow-lg">
                <img 
                  src={property.images[activeImage] || "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800&q=80"} 
                  alt="Property" 
                  className="w-full h-full object-contain"
                />
              </div>
              <div className="flex gap-4 overflow-x-auto pb-2">
                {property.images.map((img, idx) => (
                  <button 
                    key={idx}
                    onClick={() => setActiveImage(idx)}
                    className={`relative w-24 h-24 flex-shrink-0 rounded-lg overflow-hidden border-2 ${activeImage === idx ? 'border-primary ring-2 ring-primary/20' : 'border-transparent'}`}
                  >
                    <img src={img} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            </div>

            {/* Overview Cards */}
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-white p-6 rounded-xl border text-center shadow-sm">
                <BedDouble className="w-8 h-8 mx-auto text-primary mb-2" />
                <div className="font-bold text-xl">{property.bedrooms}</div>
                <div className="text-sm text-muted-foreground">Bedrooms</div>
              </div>
              <div className="bg-white p-6 rounded-xl border text-center shadow-sm">
                <Bath className="w-8 h-8 mx-auto text-primary mb-2" />
                <div className="font-bold text-xl">{property.bathrooms}</div>
                <div className="text-sm text-muted-foreground">Bathrooms</div>
              </div>
              <div className="bg-white p-6 rounded-xl border text-center shadow-sm">
                <Square className="w-8 h-8 mx-auto text-primary mb-2" />
                <div className="font-bold text-xl">{property.area}</div>
                <div className="text-sm text-muted-foreground">Sq. Ft.</div>
              </div>
            </div>

            {/* Description */}
            <div className="bg-white p-8 rounded-2xl shadow-sm border">
              <h3 className="text-xl font-bold mb-4">Description</h3>
              <p className="text-muted-foreground leading-relaxed whitespace-pre-line">{property.description}</p>
            </div>

            {/* Amenities */}
            <div className="bg-white p-8 rounded-2xl shadow-sm border">
              <h3 className="text-xl font-bold mb-6">Amenities</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-y-4 gap-x-8">
                {property.amenities.map((amenity, i) => (
                  <div key={i} className="flex items-center text-muted-foreground">
                    <CheckCircle2 className="w-5 h-5 mr-3 text-green-500" />
                    {amenity}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar - Enquiry Form */}
          <div className="lg:col-span-1">
            <div className="bg-white p-6 rounded-2xl shadow-lg border sticky top-24">
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <User className="w-8 h-8 text-primary" />
                </div>
                <h3 className="font-bold text-lg">Contact Agent</h3>
                <p className="text-sm text-muted-foreground">Get more details about this property</p>
              </div>

              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <div className="relative">
                            <User className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                            <Input placeholder="Name" {...field} className="pl-9" />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <div className="relative">
                            <Phone className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                            <Input placeholder="Phone" {...field} className="pl-9" />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <div className="relative">
                            <Mail className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                            <Input placeholder="Email" {...field} className="pl-9" />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Textarea placeholder="Message" {...field} rows={4} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <Button type="submit" className="w-full h-12 text-lg font-semibold" disabled={createEnquiry.isPending}>
                    {createEnquiry.isPending ? "Sending..." : "Send Enquiry"}
                  </Button>
                </form>
              </Form>
              <div className="mt-4 text-xs text-center text-muted-foreground">
                By sending this enquiry, you agree to our Terms & Conditions
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
