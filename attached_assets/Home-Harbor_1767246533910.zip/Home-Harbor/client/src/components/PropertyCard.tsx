import { Link } from "wouter";
import { type Property } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { BedDouble, Bath, Square, MapPin } from "lucide-react";

interface PropertyCardProps {
  property: Property;
}

export function PropertyCard({ property }: PropertyCardProps) {
  return (
    <div className="group bg-card rounded-xl overflow-hidden border shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
      {/* Image Container */}
      <div className="relative aspect-[4/3] overflow-hidden">
        <Link href={`/property/${property.id}`}>
          <div className="cursor-pointer w-full h-full">
            <img
              src={property.images[0] || "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800&q=80"}
              alt={property.title}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
          </div>
        </Link>
        <div className="absolute top-3 left-3 flex gap-2">
          <Badge className="bg-white/90 text-foreground hover:bg-white font-semibold shadow-sm backdrop-blur-sm">
            {property.type === 'rent' ? 'For Rent' : 'For Sale'}
          </Badge>
          {property.isVerified && (
            <Badge variant="secondary" className="bg-green-500/90 text-white border-none hover:bg-green-500 shadow-sm backdrop-blur-sm">
              Verified
            </Badge>
          )}
        </div>
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/60 to-transparent text-white">
           <h3 className="font-bold text-xl">₹ {(property.price / 100000).toFixed(2)} L</h3>
        </div>
      </div>

      {/* Content */}
      <div className="p-5">
        <Link href={`/property/${property.id}`}>
          <h3 className="font-display font-semibold text-lg text-foreground line-clamp-1 hover:text-primary transition-colors cursor-pointer">
            {property.title}
          </h3>
        </Link>
        
        <div className="flex items-center text-muted-foreground mt-2 text-sm">
          <MapPin className="w-4 h-4 mr-1 text-primary" />
          <span className="line-clamp-1">{property.location}, {property.city}</span>
        </div>

        <div className="grid grid-cols-3 gap-2 mt-4 pt-4 border-t text-sm text-muted-foreground">
          <div className="flex flex-col items-center gap-1">
            <div className="flex items-center gap-1 font-medium text-foreground">
              <BedDouble className="w-4 h-4" /> {property.bedrooms}
            </div>
            <span className="text-xs">Beds</span>
          </div>
          <div className="flex flex-col items-center gap-1 border-l border-r">
            <div className="flex items-center gap-1 font-medium text-foreground">
              <Bath className="w-4 h-4" /> {property.bathrooms}
            </div>
            <span className="text-xs">Baths</span>
          </div>
          <div className="flex flex-col items-center gap-1">
            <div className="flex items-center gap-1 font-medium text-foreground">
              <Square className="w-4 h-4" /> {property.area}
            </div>
            <span className="text-xs">sq ft</span>
          </div>
        </div>

        <div className="mt-5">
          <Link href={`/property/${property.id}`}>
            <Button className="w-full bg-secondary text-secondary-foreground hover:bg-primary hover:text-primary-foreground transition-colors font-semibold">
              View Details
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
