import { Link } from "wouter";

export function Footer() {
  return (
    <footer className="bg-slate-900 text-slate-300 py-12 mt-20">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <span className="text-white font-bold">360</span>
              </div>
              <span className="font-display font-bold text-xl text-white">360 Property</span>
            </div>
            <p className="text-sm leading-relaxed text-slate-400">
              India's most innovative real estate platform for buyers, sellers, and agents. Find your perfect home today.
            </p>
          </div>

          <div>
            <h4 className="font-bold text-white mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li><Link href="/buy" className="hover:text-primary transition-colors">Buy Property</Link></li>
              <li><Link href="/rent" className="hover:text-primary transition-colors">Rent Property</Link></li>
              <li><Link href="/new-launch" className="hover:text-primary transition-colors">New Projects</Link></li>
              <li><Link href="/post-property" className="hover:text-primary transition-colors">Post Property</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-white mb-4">Company</h4>
            <ul className="space-y-2 text-sm">
              <li><Link href="/about" className="hover:text-primary transition-colors">About Us</Link></li>
              <li><Link href="/contact" className="hover:text-primary transition-colors">Contact Us</Link></li>
              <li><Link href="/careers" className="hover:text-primary transition-colors">Careers</Link></li>
              <li><Link href="/terms" className="hover:text-primary transition-colors">Terms & Conditions</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-white mb-4">Connect</h4>
            <p className="text-sm mb-2 text-slate-400">123 Business Park, Mumbai, MH 400001</p>
            <p className="text-sm mb-4 text-slate-400">+91 98765 43210</p>
            <div className="flex gap-4">
              {/* Social Icons Placeholder */}
              <div className="w-8 h-8 bg-slate-800 rounded-full hover:bg-primary transition-colors cursor-pointer" />
              <div className="w-8 h-8 bg-slate-800 rounded-full hover:bg-primary transition-colors cursor-pointer" />
              <div className="w-8 h-8 bg-slate-800 rounded-full hover:bg-primary transition-colors cursor-pointer" />
            </div>
          </div>
        </div>
        
        <div className="border-t border-slate-800 mt-12 pt-8 text-center text-sm text-slate-500">
          © {new Date().getFullYear()} 360 Property. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
