import { db } from "./db";
import {
  users, properties, enquiries,
  type User, type InsertUser,
  type Property, type InsertProperty, type PropertyFilter,
  type Enquiry, type InsertEnquiry
} from "@shared/schema";
import { eq, and, gte, lte, desc } from "drizzle-orm";

export interface IStorage {
  // User
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Property
  createProperty(property: InsertProperty): Promise<Property>;
  getProperty(id: number): Promise<Property | undefined>;
  getProperties(filter?: PropertyFilter): Promise<Property[]>;
  getUserProperties(userId: number): Promise<Property[]>;
  updateProperty(id: number, property: Partial<InsertProperty>): Promise<Property | undefined>;
  deleteProperty(id: number): Promise<void>;

  // Enquiry
  createEnquiry(enquiry: InsertEnquiry): Promise<Enquiry>;
  getEnquiriesForUser(userId: number): Promise<Enquiry[]>;
}

export class DatabaseStorage implements IStorage {
  // User
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  // Property
  async createProperty(property: InsertProperty): Promise<Property> {
    const [newProperty] = await db.insert(properties).values(property).returning();
    return newProperty;
  }

  async getProperty(id: number): Promise<Property | undefined> {
    const [property] = await db.select().from(properties).where(eq(properties.id, id));
    return property;
  }

  async getProperties(filter?: PropertyFilter): Promise<Property[]> {
    let conditions = [];
    
    if (filter?.type) conditions.push(eq(properties.type, filter.type));
    if (filter?.city) conditions.push(eq(properties.city, filter.city));
    if (filter?.bedrooms) conditions.push(gte(properties.bedrooms, filter.bedrooms));
    if (filter?.minPrice) conditions.push(gte(properties.price, filter.minPrice));
    if (filter?.maxPrice) conditions.push(lte(properties.price, filter.maxPrice));
    conditions.push(eq(properties.isActive, true));

    return await db.select()
      .from(properties)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(properties.createdAt));
  }

  async getUserProperties(userId: number): Promise<Property[]> {
    return await db.select().from(properties).where(eq(properties.ownerId, userId));
  }

  async updateProperty(id: number, updates: Partial<InsertProperty>): Promise<Property | undefined> {
    const [updated] = await db.update(properties)
      .set(updates)
      .where(eq(properties.id, id))
      .returning();
    return updated;
  }

  async deleteProperty(id: number): Promise<void> {
    await db.delete(properties).where(eq(properties.id, id));
  }

  // Enquiry
  async createEnquiry(enquiry: InsertEnquiry): Promise<Enquiry> {
    const [newEnquiry] = await db.insert(enquiries).values(enquiry).returning();
    return newEnquiry;
  }

  async getEnquiriesForUser(userId: number): Promise<Enquiry[]> {
    // Get all properties owned by user, then get enquiries for those properties
    // This is a simplified approach. In SQL we could join.
    const userProperties = await this.getUserProperties(userId);
    const propertyIds = userProperties.map(p => p.id);
    
    if (propertyIds.length === 0) return [];

    // Filter enquiries where propertyId is in user's property IDs
    // Drizzle `inArray` would be better here but iterating for now or using raw query if needed
    // Let's rely on a join if possible or just fetch all for now (MVP)
    // Correct approach with Drizzle:
    const result = await db.select({
      enquiry: enquiries,
      property: properties,
    })
    .from(enquiries)
    .innerJoin(properties, eq(enquiries.propertyId, properties.id))
    .where(eq(properties.ownerId, userId));
    
    return result.map(r => r.enquiry);
  }
}

export const storage = new DatabaseStorage();
