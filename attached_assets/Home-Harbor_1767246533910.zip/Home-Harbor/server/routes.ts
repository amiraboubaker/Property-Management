import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth, hashPassword } from "./auth";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Initialize Authentication
  setupAuth(app);

  // === AUTH ROUTES ===
  
  app.post(api.auth.register.path, async (req, res) => {
    try {
      const input = api.auth.register.input.parse(req.body);
      const existing = await storage.getUserByEmail(input.email);
      if (existing) {
        return res.status(400).json({ message: "Email already exists" });
      }

      const hashedPassword = await hashPassword(input.password);
      const user = await storage.createUser({ ...input, password: hashedPassword });
      
      req.login(user, (err) => {
        if (err) throw err;
        res.status(201).json(user);
      });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.post(api.auth.login.path, (req, res, next) => {
    // We can't use the Zod schema directly in passport's callback easily, 
    // but passport-local handles the extraction.
    // We just need to handle the response.
    const schema = api.auth.login.input;
    const validation = schema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({ message: "Invalid input" });
    }

    // passport.authenticate calls the strategy we defined in auth.ts
    const auth = passport.authenticate("local", (err: any, user: any, info: any) => {
      if (err) return next(err);
      if (!user) return res.status(401).json({ message: info?.message || "Authentication failed" });
      
      req.login(user, (err) => {
        if (err) return next(err);
        return res.status(200).json(user);
      });
    });
    
    auth(req, res, next);
  });

  app.post(api.auth.logout.path, (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.status(200).json();
    });
  });

  app.get(api.auth.me.path, (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    res.json(req.user);
  });


  // === PROPERTY ROUTES ===

  app.get(api.properties.list.path, async (req, res) => {
    try {
      // Coerce query params
      const filter = {
        type: req.query.type as string,
        city: req.query.city as string,
        minPrice: req.query.minPrice ? Number(req.query.minPrice) : undefined,
        maxPrice: req.query.maxPrice ? Number(req.query.maxPrice) : undefined,
        bedrooms: req.query.bedrooms ? Number(req.query.bedrooms) : undefined,
      };
      
      const properties = await storage.getProperties(filter);
      res.json(properties);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get(api.properties.get.path, async (req, res) => {
    const property = await storage.getProperty(Number(req.params.id));
    if (!property) return res.status(404).json({ message: "Property not found" });
    res.json(property);
  });

  app.post(api.properties.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Login required" });
    
    try {
      const input = api.properties.create.input.parse(req.body);
      const property = await storage.createProperty({
        ...input,
        ownerId: (req.user as any).id, // Attach logged in user
      });
      res.status(201).json(property);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.put(api.properties.update.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Login required" });

    try {
      const id = Number(req.params.id);
      const existing = await storage.getProperty(id);
      
      if (!existing) return res.status(404).json({ message: "Property not found" });
      if (existing.ownerId !== (req.user as any).id) {
        return res.status(403).json({ message: "Not authorized" });
      }

      const input = api.properties.update.input.parse(req.body);
      const updated = await storage.updateProperty(id, input);
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.delete(api.properties.delete.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Login required" });

    const id = Number(req.params.id);
    const existing = await storage.getProperty(id);
    
    if (!existing) return res.status(404).json({ message: "Property not found" });
    if (existing.ownerId !== (req.user as any).id) {
      return res.status(403).json({ message: "Not authorized" });
    }

    await storage.deleteProperty(id);
    res.status(204).send();
  });


  // === ENQUIRY ROUTES ===

  app.post(api.enquiries.create.path, async (req, res) => {
    try {
      const input = api.enquiries.create.input.parse(req.body);
      // If user is logged in, use their ID
      const userId = req.isAuthenticated() ? (req.user as any).id : undefined;
      
      const enquiry = await storage.createEnquiry({ ...input, userId });
      res.status(201).json(enquiry);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.get(api.enquiries.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Login required" });
    
    const enquiries = await storage.getEnquiriesForUser((req.user as any).id);
    res.json(enquiries);
  });

  // === SEED DATA ===
  await seed();

  return httpServer;
}

async function seed() {
  const existing = await storage.getProperties();
  if (existing.length === 0) {
    console.log("Seeding data...");
    
    // Create Agent User
    const hashedPassword = await hashPassword("password123");
    const agent = await storage.createUser({
      name: "John Agent",
      email: "agent@360property.com",
      password: hashedPassword,
      isAgent: true,
    });

    // Create Sample Properties
    await storage.createProperty({
      title: "Luxury 3BHK Apartment in Downtown",
      description: "Beautiful apartment with city view, gym access, and swimming pool. Close to metro station.",
      type: "buy",
      price: 150000,
      city: "New York",
      location: "Manhattan, NY",
      bedrooms: 3,
      bathrooms: 2,
      area: 1800,
      images: [
        "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=1000",
        "https://images.unsplash.com/photo-1484154218962-a1c002085d2f?auto=format&fit=crop&q=80&w=1000"
      ],
      amenities: ["Gym", "Pool", "Parking", "Security"],
      ownerId: agent.id,
      isActive: true,
      isVerified: true
    });

    await storage.createProperty({
      title: "Cozy Studio for Rent",
      description: "Perfect for students or young professionals. Fully furnished.",
      type: "rent",
      price: 2500,
      city: "San Francisco",
      location: "SOMA, SF",
      bedrooms: 1,
      bathrooms: 1,
      area: 600,
      images: [
        "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&q=80&w=1000"
      ],
      amenities: ["WiFi", "Furnished"],
      ownerId: agent.id,
      isActive: true,
      isVerified: false
    });
    
    console.log("Seeding complete.");
  }
}
